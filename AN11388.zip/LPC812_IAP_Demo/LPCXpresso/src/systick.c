/****************************************************************************
 *   
 *   Project: Systick.c 
 *
 *   Description:
 *     A periodic interrupt using the systick.  The function is loaded into
 *		 SRAM during run time to allow access during IAP calls.
 *
 ****************************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
****************************************************************************/


#include "LPC8xx.h"
__attribute__ ((__section__(".data.ramfunc")))

void SysTick_Handler(void)
{
	LPC_GPIO_PORT->NOT0 = (1<<7);
}

